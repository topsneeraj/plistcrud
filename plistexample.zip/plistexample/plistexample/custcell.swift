//
//  custcell.swift
//  plistexample
//
//  Created by TOPS on 10/8/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
