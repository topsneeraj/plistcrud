//
//  ViewController.swift
//  plistexample
//
//  Created by TOPS on 10/8/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var btn: UIButton!
    var pos :Int  = 0;
    
    @IBOutlet weak var tbl: UITableView!
    var finalarr : [Any] = [];
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    
    @IBOutlet weak var txtempmob: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        print(getpath());
        
        finalarr = getdata();
        
        
        let fmg = FileManager();
        
        if !fmg.fileExists(atPath: getpath()) {
            
            var arr : [Any] = [];
            
            
            let temp :[String:String] = [:]
            
            arr.append(temp);
            
            
            var dic : [String:Any] = [:]
            dic["Records"] = arr;
            
        
            
            
            let finaldic = NSDictionary(dictionary: dic);
            
            finaldic.write(toFile: getpath(), atomically: true);
            
            
            
        }
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    func getpath() -> String {
        
        let arrpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let path = arrpath[0] as! String;
        
        let fullpath = path.appending("/profile.plist");
        
        return fullpath;
        
    }
    
    func getdata() -> [Any] {
        
        
        
        
        print(getpath());
        let fmg = FileManager();
        if fmg.fileExists(atPath: getpath()) {
            
            let dic = NSDictionary(contentsOfFile: getpath());
            
            print(dic);
            
            var arr = dic?.value(forKey: "Records") as! [Any];
            
            return arr;
            
            
            
            
            
        }
        
        return  []
        

    }
    @IBAction func btnclick(_ sender: Any) {
        
        
        if btn.titleLabel?.text == "update" {
            
            
            let fmg = FileManager();
            
            if fmg.fileExists(atPath: getpath()) {
                
                
                let dic = NSDictionary(contentsOfFile: getpath());
                
                var arr = dic?["Records"] as! [Any];
                
                
                
                arr.remove(at: pos);
                
            
                let dic1 = ["emp_name":txtempname.text!,"emp_add":txtempadd.text!,"emp_mob":txtempmob.text!];
                
                arr.append(dic1);
                
                dic?.setValue(arr, forKey: "Records");
                
                
                
                let finaldic = NSDictionary(dictionary: dic!);
                
                finaldic.write(toFile: getpath(), atomically: true);
                
                
                btn.setTitle("create", for: .normal);
                txtempname.becomeFirstResponder();
                
                
                clear();
                
            finalarr = getdata();
            
                tbl.reloadData();
                
            }
            
            
            
            
        }
        else
        
        {
        

        print(getpath());
        
        let fmg = FileManager();
        
        if fmg.fileExists(atPath: getpath()) {
            
            
              let dic = NSDictionary(contentsOfFile: getpath());
            
            var arr = dic?["Records"] as! [Any];
            
            
        
            
            let dic1 = ["emp_name":txtempname.text!,"emp_add":txtempadd.text!,"emp_mob":txtempmob.text!];
            
            arr.append(dic1);
            
            dic?.setValue(arr, forKey: "Records");
            
            
            
            let finaldic = NSDictionary(dictionary: dic!);
            
            finaldic.write(toFile: getpath(), atomically: true);
            
            txtempname.becomeFirstResponder();
            
            
            clear();
            
            finalarr = getdata();
            
            tbl.reloadData();

            
        }
        
    }
        
    }
    
    
    func clear() {
        
        txtempname.text = "";
        txtempmob.text = "";
        txtempadd.text = "";
        
    }
    
    
    @IBAction func btndisp(_ sender: Any) {
        
        
        let arrpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let path = arrpath[0] as! String;
        
        let fullpath = path.appending("/profile.plist");
        
        print(fullpath);
        let fmg = FileManager();
        if fmg.fileExists(atPath: fullpath) {
            
            let dic = NSDictionary(contentsOfFile: fullpath);
            
            print(dic);
            
        
            
            
        }
        
        
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return finalarr.count;
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        let dic = finalarr[indexPath.row] as! [String:String];
        
        cell.textLabel?.text = dic["emp_name"];
        cell.detailTextLabel?.text = dic["emp_add"];
        
        
        
        return cell;
        
        
        
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        
        
        let dic = NSDictionary(contentsOfFile: getpath());
        
        var arr = dic?["Records"] as! [Any];
        
        
        arr.remove(at: indexPath.row);
        
        finalarr.remove(at: indexPath.row);
        
      
        

       // arr.append(dic);
        
        dic?.setValue(arr, forKey: "Records");
        
        
        
        let finaldic = NSDictionary(dictionary: dic!);
        
        finaldic.write(toFile: getpath(), atomically: true);
        
        tableView.reloadData();
        
        
        
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        let dic = finalarr[indexPath.row] as! [String:String];
        
        pos = indexPath.row;
        
        txtempname.text = dic["emp_name"];
        txtempmob.text = dic["emp_mob"];
        txtempadd.text = dic["emp_add"];
        
        
        btn.setTitle("update", for: .normal);
        
        
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

